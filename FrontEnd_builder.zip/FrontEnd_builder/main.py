import tkinter as tk


#color
BG = "#F5F1EB"
DARK = "#3E2723"
BROWN = "#6F4E37"
LIGHT_BROWN = "#A67B5B"
WHITE = "#FFFFFF"
GREEN = "#4CAF50"
RED = "#D9534F"
GRAY = "#777777"
light = "#F5F5F5"
#end color

#build window
window = tk.Tk()

window.title("Coffee Shop POS")
window.geometry("1200x700")
window.configure(bg=BG)
#Header
header = tk.Frame(
    window,
    bg = BROWN,
    height = 70
)
header.pack(fill="x")
header.pack_propagate(False)

#Title of header
title = tk.Label(
    header,
    text="Coffee Shop",
    font=("Arial", 12, "bold"),
    bg=BROWN,
    fg=WHITE,
)
title.pack(
    side="left",
    padx=25,
)
#End Title of header

#Cashier
cashier = tk.Label(
    header,
    text="Cashier",
    font=("Arial", 12, "bold"),
    bg=BROWN,
    fg=WHITE,
)
cashier.pack(side="right" , padx=25)
#End Cashier
#Main Content or Container
main_frame = tk.Frame(
    window,
    bg = light,
)
main_frame.pack(
    fill="both",
    expand=True,
    padx=20,
    pady=20,
)
#product area
products_Frame = tk.Frame(
    main_frame,
    bg = WHITE,
)
products_Frame.pack(
    side="left",
    fill="both",
    expand=True,
    padx = (0,10)
)
#product title
products_title = tk.Label(
    products_Frame,
    text="Products",
    font=("Arial", 20, "bold"),
    bg=WHITE,
    )
products_title.pack(
    anchor="w",
    padx=20,
    pady=20
)
#End product title
#Product Button
#product data
product_data = [
    {
        "id": 1,
        "name": "Latte",
        "price": 3.50,
        "category": "Coffee",
        "quantity": 1
    },
    {
        "id": 2,
        "name": "Cappuccino",
        "price": 3.00,
        "category": "Coffee",
        "quantity": 1
    },
    {
        "id": 3,
        "name": "Green Tea",
        "price": 2.50,
        "category": "Tea",
        "quantity": 1
    }
]
#End product data
product_grid = tk.Frame(
    products_Frame,
    bg= WHITE,
)
product_grid.pack(
    padx = 20,
    pady = 10
)
#Function Add Cart
cart = []
#function Update Cart
def update_cart():
    order_list.delete(0, tk.END)
    subtotal = 0
    for item in cart:
        item_total = item["quantity"] * item["price"]
        order_list.insert(
            tk.END,
            f"{item['name']}       x{item['quantity']}      ${item_total:.2f} ",
        )
        subtotal += item_total
    tax = subtotal * 0.10
    total = subtotal + tax
    subtotal_label.config(
        text = f"Subtotal: ${subtotal:.2f}",
    )
    tax_label.config(
        text = f"Tax: ${tax:.2f}",
    )
    total_label.config(
        text = f"Total: $   {total:.2f}",
    )

#End function Update
def add_to_cart( name, price):

    for item in cart:
        item_name = item["name"]
        if name == item_name:
            item["quantity"] += 1
            update_cart()
            return
    cart.append({
        "name": name,
        "price": price,
        "quantity": 1
    })

    update_cart()
#loop from product_data
for index, product in enumerate(product_data):
    row = index // 3
    column = index % 3
    #data import
    name = product["name"]
    price = product["price"]
    button = tk.Button(
        product_grid,
        text= f"{name}\n${price:.2f}",
        font=("Arial", 13, "bold"),
        width=15,
        height=5,
        bg="#EFE2D0",
        activebackground="#D7B899",
        relief="flat",
        command=lambda n=name , p=price: add_to_cart(n, p)
    )
    button.grid(
        row=row,
        column=column,
        padx=10,
        pady=10
    )
# End Loop
#End Function Add Cart

#Function Clear Cart
def clear_cart():
    cart.clear()
    update_cart()
#End Product Frame

#Order Area
order_frame = tk.Frame(
    main_frame,
    bg = WHITE,
    width = 350,
)
order_frame.pack(
    side="right",
    fill="y",
)
order_frame.pack_propagate(False)

order_title = tk.Label(
    order_frame,
    text="Current Orders",
    font=("Arial", 20, "bold"),
    bg = WHITE,
)
order_title.pack(
    anchor="w",
    padx=20,
    pady=20
)
#Order List
order_list = tk.Listbox(
    order_frame,
    font=("Arial", 12),
    height=15
)
order_list.pack(
    fill = "both",
    padx = 20,
    pady = 10
)
#End Order List
#Total
subtotal_label = tk.Label(
    order_frame,
    text = "Subtotal: $0.00",
    font=("Arial", 13),
    bg = WHITE
)
subtotal_label.pack(
    anchor="w",
    padx=20,
    pady=5
)
#End Sub-total
#Tax
tax_label = tk.Label(
    order_frame,
    text = "Tax: $0.00",
    font=("Arial", 13),
    bg = WHITE
)
tax_label.pack(
    anchor="w",
    padx=20,
    pady=5
)
#End Tax Label
#Total Label
total_label = tk.Label(
    order_frame,
    text = "Total: $0.00",
    font=("Arial", 13),
    bg = WHITE
)
total_label.pack(
    anchor="w",
    padx=20,
    pady=5
)
#End Total Label

#Button Order Area
button_frame = tk.Frame(
    order_frame,
    bg = WHITE
)
button_frame.pack(
    fill="x",
    padx=20,
    pady=20
)
#Clear Button
clear_button = tk.Button(
    button_frame,
    text="Clear",
    font=("Arial", 12, "bold"),
    bg="#D9534F",
    fg=WHITE,
    height=2,
    command=clear_cart
)
clear_button.pack(
    side="left",
    fill="x",
    expand=True,
    padx=(0,5)
    )
#End Clear Button
#Pay Button
pay_button = tk.Button(
    button_frame,
    text="Pay",
    font=("Arial", 12, "bold"),
    bg="#5CB85C",
    fg=WHITE,
    height=2
)
pay_button.pack(
    side = "right",
    fill="x",
    expand=True,
    padx =(5,0)
)
#End Pay Button
#End Button Order Area
#End Order Area
#End Main Content

#run application
window.mainloop()

#build new window to print receipt